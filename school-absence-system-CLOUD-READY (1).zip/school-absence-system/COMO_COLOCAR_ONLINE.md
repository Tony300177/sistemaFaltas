# Guia: Como Colocar seu Sistema Online (Grátis)

Este sistema foi migrado para **PostgreSQL**, permitindo o uso do **Supabase**, que é muito mais estável que o MySQL local.

## Passo 1: Criar o Banco de Dados no Supabase
1. Acesse [supabase.com](https://supabase.com/) e crie uma conta gratuita.
2. Crie um novo projeto (ex: `SistemaFaltas`).
3. Vá em **Project Settings** (ícone de engrenagem) -> **Database**.
4. Procure por **Connection String**, selecione a aba **URI** e copie o endereço.
   * *Dica: Lembre-se da senha que você criou ao criar o projeto.*

## Passo 2: Configurar o Servidor
1. No seu servidor (Render ou Railway), adicione uma variável de ambiente chamada `DATABASE_URL`.
2. Cole a URI que você copiou do Supabase.
   * *Importante: Substitua `[YOUR-PASSWORD]` pela sua senha real.*

## Passo 3: Deploy no Render (Recomendado)
1. Crie uma conta no [Render.com](https://render.com/).
2. Conecte seu GitHub onde o código está salvo.
3. Escolha **Web Service**.
4. Configurações:
   * **Root Directory**: `server`
   * **Build Command**: `npm install`
   * **Start Command**: `node server.js`
5. Em **Environment Variables**, adicione a `DATABASE_URL`.

## Passo 4: O Frontend
Como o servidor agora serve os arquivos estáticos (pasta `dist`), ao acessar o link do seu Web Service no Render, o sistema já deve abrir completo!

---
**Dúvidas?** O banco de dados agora é gerenciado na nuvem. Você pode ver todos os alunos e faltas diretamente no painel do Supabase em "Table Editor".
